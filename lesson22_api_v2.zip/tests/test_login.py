import os
from common.logger_handler import logger


def test_login():
    pass