a = '{"name": "yuz", "female": None}'
print(eval(a))

# 序列化和反序列化
# 充值
# 用例的依赖，登陆功能。