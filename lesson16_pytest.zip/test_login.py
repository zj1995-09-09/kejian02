import pytest

@pytest.mark.smoke
def test_login():
    pass

