# 收集用例，运行用例
import pytest

if __name__ == '__main__':
    pytest.main()

