#
print(__file__)
