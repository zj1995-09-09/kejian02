# python环境

name = "'yuze'"
print(name)

# 字典的表示
# dict1 = {"name": "yuz"}
# dict2 = '{"name": "yuz"}'
#
# print(dict1 == dict2)

# 这个是json
json_1 = '{"name": "abc"}'
# 不是 json, 必须要用双引号
json_2 = "{'name': 'abc'}"

